"use strict";

var el = document.getElementById('sortable');
var sortable = new Sortable.create(el);