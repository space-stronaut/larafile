<p>Halo {{ $nama }},</p>

<p>Selamat Akun Partner Anda sudah aktif, berikut informasi akses login Anda:</p>

<p>url login: <em>{{ $app_url }}/login</em><br>
email: <em>{{ $email }}</em><br>
password: <em>password yang anda isi ketika melakukan registrasi</em></p>

<p>silahkan melakukan login dan mulai membuat program Anda</p>

<p>Jika anda membutukan bantuan, Anda bisa menghubungi staff Admin kami melalui email info@sedekahitumudah.com atau nomor telp / whatsapp berikut 081321425825</p>

<p>Terima Kasih</p>