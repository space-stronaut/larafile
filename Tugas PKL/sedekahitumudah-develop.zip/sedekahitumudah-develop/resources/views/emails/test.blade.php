<p>Halo {{ $nama }},</p>
<p>ini hanya test email dari laravel aja</p>
