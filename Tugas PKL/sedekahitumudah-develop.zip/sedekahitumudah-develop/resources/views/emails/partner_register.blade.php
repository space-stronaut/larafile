<p>Halo {{ $nama }},</p>

<p>Terima kasih telah melakukan pendaftaran di Sedekah itu Mudah.</p>

<p>Admin kami akan melakukan verifikasi data terlebih dahulu, sebelum akun partner Anda aktif.</p>

<p>Proses verifikasi maksimal 2 x 24 jam. Silahkan tunggu email konfirmasi kembali dari kami.</p>

<p>Jika anda membutukan bantuan, Anda bisa menghubungi staff Admin kami melalui email info@sedekahitumudah.com atau nomor telp / whatsapp berikut 081321425825</p>

<p>Terima Kasih</p>
