<p>Halo {{ $nama }},</p>

<p>Mohon maaf Permintaaan pendaftaran Partner Anda tidak dapat kami setujui, karena data yang kami terima kurang valid.</p>

<p>Namun jangan khawatir, Anda dapat melakukan request pendaftaran partner ulang kembali di link url berikut:</p>

<p>{{ $app_url }}/register-partner</p>

<p>Jika anda membutukan bantuan, Anda bisa menghubungi staff Admin kami melalui email info@sedekahitumudah.com atau nomor telp / whatsapp berikut 081321425825</p>

<p>Terima Kasih</p>