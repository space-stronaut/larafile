<p>Halo {{ $name }},</p>

<p>Ajuan Pencairan Dana Sudah diterima, Pembayaran sedang dalam Proses</p>

<p>Mohon tunggu untuk pemberitahuan Selanjutnya Proses Pembayaran akan berlangsung dalam 72 jam paling lambat</p>

<p>Jika anda membutukan bantuan, Anda bisa menghubungi staff Admin kami melalui email info@sedekahitumudah.com atau nomor telp / whatsapp berikut 081321425825</p>

<p>Terima Kasih</p>