<p>{{ $name }} Mengajukan Pencairan Dana</p>

<p> Ajuan Pencairan Dana Sebanyak :
    <?php    
    $angka_format = number_format($jumlah,0,"",".");
    echo "Rp. ".$angka_format. ",-";         
    ?>

</p>

<p>Mohon Diperiksa Ajuan Pencairan Dana nya di Panel Admin</p>

<p>Terima Kasih</p>