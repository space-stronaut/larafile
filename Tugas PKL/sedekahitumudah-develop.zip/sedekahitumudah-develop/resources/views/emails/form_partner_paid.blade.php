<p>Halo {{ $name }},</p>

<p>Ajuan Pencairan Dana Sudah Di Transfer sebanyak 
    <?php    
    $angka_format = number_format($balance,0,"",".");
    echo "Rp. ".$angka_format. ",-";     
    
    
    ?>

</p>

<p>Silahkan Cek Rekening Anda</p>

<p>Jika anda membutukan bantuan, Anda bisa menghubungi staff Admin kami melalui email info@sedekahitumudah.com atau nomor telp / whatsapp berikut 081321425825</p>

<p>Terima Kasih</p>